<?php 

include 'conexao_db/conexao.php';
include 'script/password.php';

/*echo*/ $email = $_POST['email'];
/*echo '<br>';*/
/*echo*/ $senha = sha1($_POST['senha']);
/*echo '<br>';*/

$select = "SELECT email, senha FROM usuarios WHERE email = '$email' AND senha = '$senha'";

$execute = mysqli_query($conexao,$select);

$total = mysqli_num_rows($execute);

while ($array = mysqli_fetch_assoc($execute)) {

	$senhaArray = $array['senha'];
	$emailArray = $array['email'];
	
	if ($total == 1) {

		if ($emailArray == $email && $senhaArray == $senha) {
			header("Location: menu.php");
		}
		else{
			return header("Location: erro.php");
		} 
	}
	else{
		return header("Location: erro.php");
	}
}
